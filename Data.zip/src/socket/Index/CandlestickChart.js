import React, { useEffect, useRef } from "react";
import { createChart } from "lightweight-charts";

const CandlestickChart = ({ data }) => {
  const chartContainerRef = useRef(null);
  const chartInstanceRef = useRef(null);

  useEffect(() => {
    if (!data || Object.keys(data).length === 0) return;

    // Prepare data for candlestick chart
    const candlestickData = Object.keys(data).map((key) => {
      const feed = data[key];
      const ohlc = feed.ff.indexFF.marketOHLC.ohlc[1];
      return {
        time: new Date(parseInt(ohlc.ts)),
        open: ohlc.open,
        high: ohlc.high,
        low: ohlc.low,
        close: ohlc.close,
      };
    });

    // Sort the data by time in ascending order
    candlestickData.sort((a, b) => a.time.getTime() - b.time.getTime());

    // Create the chart instance if not already created
    if (!chartInstanceRef.current) {
      const chart = createChart(chartContainerRef.current, {
        width: chartContainerRef.current.clientWidth,
        height: 400,
      });
      chartInstanceRef.current = chart;
    }

    // Get the chart instance
    const chart = chartInstanceRef.current;

    // Add candlestick series and set data
    const candleSeries = chart.addCandlestickSeries();
    candleSeries.setData(candlestickData);

    // Cleanup on component unmount
    return () => {
      if (chart) {
        chart.remove();
        chartInstanceRef.current = null;
      }
    };
  }, [data]);

  return <div ref={chartContainerRef} style={{ height: "400px" }}></div>;
};

export default CandlestickChart;
